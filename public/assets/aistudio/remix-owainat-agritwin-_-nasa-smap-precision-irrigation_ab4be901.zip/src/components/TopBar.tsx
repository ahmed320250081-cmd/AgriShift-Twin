import { Languages, ShieldCheck, UserCheck } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';
import { translateOperator, translateRole } from '../i18n/translations';
import { UserProfile, UserRole, WorkspaceTab } from '../types/farm';

interface TopBarProps {
  activeTab: WorkspaceTab;
  onTabChange: (tab: WorkspaceTab) => void;
  effectiveRole: UserRole;
  authUser: UserProfile | null;
  onOpenRolePanel: () => void;
}

const NAV_TAB_IDS: WorkspaceTab[] = ['twin', 'analytics', 'weather', 'access'];

export function TopBar({
  activeTab,
  onTabChange,
  effectiveRole,
  authUser,
  onOpenRolePanel,
}: TopBarProps) {
  const { lang, toggleLang, t } = useLanguage();
  const roleLabel = translateRole(effectiveRole, lang);

  return (
    <header className="flex items-center justify-between gap-6 px-6 py-3.5 bg-[#0B1117] border-b border-slate-800 shrink-0">
      <a
        href="#top"
        onClick={(e) => {
          e.preventDefault();
          onTabChange('twin');
        }}
        className="text-lg font-semibold tracking-tight text-slate-100 whitespace-nowrap shrink-0 font-display"
      >
        {t.brandName}
      </a>

      <nav aria-label={t.navLabel} className="flex items-center gap-6 overflow-x-auto">
        {NAV_TAB_IDS.map((tabId) => {
          const isActive = activeTab === tabId;
          return (
            <button
              key={tabId}
              type="button"
              onClick={() => onTabChange(tabId)}
              aria-current={isActive ? 'page' : undefined}
              className={`py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 rounded-t-sm ${
                isActive
                  ? 'text-cyan-400 border-cyan-400'
                  : 'text-slate-400 border-transparent hover:text-slate-100 hover:border-slate-700'
              }`}
            >
              {t.tabs[tabId]}
            </button>
          );
        })}
      </nav>

      <div className="flex items-center gap-2.5 shrink-0">
        <button
          type="button"
          onClick={toggleLang}
          data-testid="language-toggle"
          aria-label={t.langToggleAria}
          className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-200 bg-[#121B26] hover:bg-slate-800 border border-slate-700 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400"
        >
          <Languages className="w-3.5 h-3.5 text-cyan-400" aria-hidden="true" />
          <span>{t.langToggleLabel}</span>
        </button>

        <button
          type="button"
          onClick={onOpenRolePanel}
          aria-label={`${t.roleAriaPrefix} ${roleLabel}. ${t.roleAriaSuffix}`}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300"
        >
          {effectiveRole === 'farm_manager' ? (
            <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
          ) : (
            <UserCheck className="w-3.5 h-3.5" aria-hidden="true" />
          )}
          <span>
            {authUser
              ? `${translateOperator(authUser.displayName.split(' ')[0], lang)} · ${roleLabel}`
              : roleLabel}
          </span>
        </button>
      </div>
    </header>
  );
}
