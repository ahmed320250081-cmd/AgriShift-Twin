import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { BookOpen, Calendar, Globe, Map as MapIcon, Satellite, Sprout } from 'lucide-react';
import { FarmerPictureFlow } from './components/flow/FarmerPictureFlow';
import { CropAtlasPage } from './components/pages/CropAtlasPage';
import { NasaTransparencyPage } from './components/pages/NasaTransparencyPage';
import { SatelliteExplorerPage } from './components/pages/SatelliteExplorerPage';
import { findGovernorateById } from './data/egyptGovernorates';
import { generateAllStrategyPlans } from './engine/rotationEngine';
import { TRANSLATIONS } from './i18n/translations';
import type {
  DigitMode,
  FarmProfile,
  Language,
  NasaTelemetryResponse,
  RotationStrategyId,
  SavedPlot,
} from './types/agrishift';
import { formatFeddanLabel, getDirectionForLang } from './utils/formatters';
import {
  getDefaultFarmProfile,
  loadCachedTelemetry,
  loadSavedFarm,
  loadSavedPlots,
  loadSavedPrefs,
  saveCachedTelemetry,
  saveFarm,
  savePlots,
  savePrefs,
} from './utils/storage';

type ActiveTab = 'plan' | 'map' | 'nasa' | 'crops';

const FALLBACK_INITIAL_TELEMETRY: NasaTelemetryResponse = {
  lat: 31.11,
  lon: 30.94,
  fetchedAt: new Date().toISOString(),
  cached: false,
  dataSource: 'demo',
  ndviTrend: 'stable',
  latestNdvi: 0.61,
  ndviSeries: [
    { date: '2026-08-15', ndvi: 0.56, quality: 'estimated' },
    { date: '2026-09-01', ndvi: 0.58, quality: 'estimated' },
    { date: '2026-09-17', ndvi: 0.6, quality: 'estimated' },
    { date: '2026-10-03', ndvi: 0.61, quality: 'estimated' },
  ],
  dailyWeather: Array.from({ length: 10 }, (_, idx) => ({
    date: `2026-10-${String(idx + 1).padStart(2, '0')}`,
    tMaxC: Number((27.8 + Math.sin(idx) * 1.1).toFixed(1)),
    tMinC: Number((15.8 + Math.cos(idx) * 0.7).toFixed(1)),
    precipMm: idx === 3 ? 2.1 : idx === 7 ? 1.4 : 0,
    solarMJm2: 19.6,
    wind2mMs: 2.3,
    rhPct: 58,
    soilWetnessPct: 49,
    et0Mm: Number((4.1 + Math.sin(idx) * 0.4).toFixed(2)),
  })),
  monthlyClimatology: [19.5, 21, 24.5, 29, 33, 35.5, 36, 35.8, 33.5, 30, 25.5, 21].map((t, i) => ({
    month: i + 1,
    tMaxC: t,
    precipMm: [18, 12, 8, 2, 0.5, 0, 0, 0, 0.2, 4, 10, 16][i],
  })),
  summary: {
    avgEt0MmDay: 4.3,
    seasonalEt0Mm: 129,
    seasonalPrecipMm: 4.8,
    irrigationNeedMm: 125,
    heatStressDays: 0,
    avgTMaxC: 28.5,
    avgTMinC: 16.2,
    avgSoilWetnessPct: 49,
    historicalSoilWetnessPct: null,
    waterStressFlag: 'low',
  },
  sources: [
    {
      id: 'power',
      status: 'demo',
      dateRange: 'Regional baseline',
      resolution: '0.5° × 0.625°',
      detail: 'Regional Nile Delta weather baseline while connecting to NASA POWER',
      url: 'https://power.larc.nasa.gov/',
    },
    {
      id: 'modis_ndvi',
      status: 'demo',
      dateRange: 'Regional baseline',
      resolution: '250 m',
      detail: 'Regional NDVI baseline while connecting to ORNL MODIS',
      url: 'https://modis.ornl.gov/',
    },
  ],
};

export default function App() {
  const initialPrefs = useMemo(() => loadSavedPrefs(), []);
  const [lang, setLang] = useState<Language>(initialPrefs.lang);
  const [digitMode, setDigitMode] = useState<DigitMode>(initialPrefs.digitMode);
  const [activeTab, setActiveTab] = useState<ActiveTab>('plan');
  const [wizardStep, setWizardStep] = useState<number>(1);
  const [farm, setFarm] = useState<FarmProfile>(() => loadSavedFarm());
  const [savedPlots, setSavedPlots] = useState<SavedPlot[]>(() => loadSavedPlots());
  const [activeStrategy, setActiveStrategy] = useState<RotationStrategyId>('balanced');
  const [telemetry, setTelemetry] = useState<NasaTelemetryResponse>(
    () => loadCachedTelemetry() ?? FALLBACK_INITIAL_TELEMETRY
  );
  const [telemetryLoading, setTelemetryLoading] = useState<boolean>(false);

  const t = TRANSLATIONS[lang];

  // Sync HTML dir & lang
  useEffect(() => {
    const dir = getDirectionForLang(lang);
    document.documentElement.dir = dir;
    document.documentElement.lang = lang === 'arz' ? 'ar-EG' : lang === 'ar' ? 'ar' : 'en';
    savePrefs(lang, digitMode);
  }, [lang, digitMode]);

  // Persist farm profile & saved plots
  useEffect(() => {
    saveFarm(farm);
  }, [farm]);

  useEffect(() => {
    savePlots(savedPlots);
  }, [savedPlots]);

  const fetchTelemetry = useCallback(
    async (lat: number, lon: number, forceRefresh = false) => {
      setTelemetryLoading(true);
      try {
        const res = await fetch(
          `/api/nasa/telemetry?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}${
            forceRefresh ? '&refresh=1' : ''
          }`
        );
        if (!res.ok) throw new Error('Telemetry fetch failed');
        const data = (await res.json()) as NasaTelemetryResponse;
        setTelemetry(data);
        saveCachedTelemetry(data);
      } catch {
        // Retain cached or demo fallback gracefully
      } finally {
        setTelemetryLoading(false);
      }
    },
    []
  );

  // Fetch NASA telemetry when coordinates change
  useEffect(() => {
    const timer = setTimeout(() => {
      void fetchTelemetry(farm.lat, farm.lon, false);
    }, 250);
    return () => clearTimeout(timer);
  }, [farm.lat, farm.lon, fetchTelemetry]);

  const plans = useMemo(() => generateAllStrategyPlans(farm, telemetry), [farm, telemetry]);

  const handleReset = () => {
    const def = getDefaultFarmProfile();
    setFarm(def);
    setWizardStep(1);
    setActiveStrategy('balanced');
  };

  const handleSavePlot = () => {
    const gov = findGovernorateById(farm.governorateId);
    const label = `${gov.name[lang]} · ${formatFeddanLabel(farm.areaFeddans, lang, digitMode)}`;
    const newPlot: SavedPlot = {
      id: `plot_${Date.now()}`,
      label,
      savedAt: new Date().toISOString(),
      strategy: activeStrategy,
      farm,
    };
    setSavedPlots((prev) => [newPlot, ...prev.filter((p) => p.label !== label)].slice(0, 8));
  };

  const handleLoadPlot = (plot: SavedPlot) => {
    setFarm(plot.farm);
    setActiveStrategy(plot.strategy);
    setActiveTab('plan');
    setWizardStep(4);
  };

  const handleDeletePlot = (id: string) => {
    setSavedPlots((prev) => prev.filter((p) => p.id !== id));
  };

  const navItems: {
    id: ActiveTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'plan', label: t.navPlan, icon: Calendar },
    { id: 'map', label: t.navMap, icon: MapIcon },
    { id: 'nasa', label: t.navNasa, icon: Satellite },
    { id: 'crops', label: t.navCrops, icon: BookOpen },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#F9F8F4] text-[#17211B] pb-20 md:pb-0">
      {/* 3-Zone Top Navigation Bar */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
          {/* Zone 1: Single Brand Mark */}
          <button
            type="button"
            onClick={() => {
              setActiveTab('plan');
              setWizardStep(1);
            }}
            className="inline-flex items-center gap-2 text-lg sm:text-xl font-extrabold text-emerald-900 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Sprout className="w-6 h-6 text-emerald-700" />
            <span>{t.appTitle}</span>
          </button>

          {/* Zone 2: 4 Clean Single-Line Nav Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-6" aria-label="Primary">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`inline-flex items-center gap-2 py-2 text-sm font-bold border-b-2 transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    active
                      ? 'border-emerald-700 text-emerald-800'
                      : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Language & Digit Selector */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setDigitMode((d) => (d === 'arabic' ? 'western' : 'arabic'))}
              className="min-h-[40px] px-3 py-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-extrabold text-slate-700 cursor-pointer whitespace-nowrap"
              title="Toggle digits"
            >
              {digitMode === 'arabic' ? t.digitsArabic : t.digitsWestern}
            </button>

            <div className="inline-flex items-center rounded-xl border border-slate-200 bg-slate-50 p-0.5">
              <Globe className="w-4 h-4 text-slate-500 mx-1.5 hidden sm:block" />
              {(['arz', 'ar', 'en'] as Language[]).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => {
                    setLang(code);
                    if (code === 'en') setDigitMode('western');
                    else setDigitMode('arabic');
                  }}
                  className={`min-h-[34px] px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer whitespace-nowrap ${
                    lang === code
                      ? 'bg-emerald-700 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {code === 'arz' ? 'مصري' : code === 'ar' ? 'فصحى' : 'EN'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 sm:py-7">
        {activeTab === 'plan' && (
          <FarmerPictureFlow
            step={wizardStep}
            setStep={setWizardStep}
            farm={farm}
            setFarm={setFarm}
            telemetry={telemetry}
            telemetryLoading={telemetryLoading}
            onRefreshTelemetry={() => void fetchTelemetry(farm.lat, farm.lon, true)}
            plans={plans}
            activeStrategy={activeStrategy}
            setActiveStrategy={setActiveStrategy}
            savedPlots={savedPlots}
            onSavePlot={handleSavePlot}
            onLoadPlot={handleLoadPlot}
            onDeletePlot={handleDeletePlot}
            lang={lang}
            digitMode={digitMode}
            onReset={handleReset}
          />
        )}

        {activeTab === 'map' && (
          <SatelliteExplorerPage
            farm={farm}
            setFarm={setFarm}
            telemetry={telemetry}
            lang={lang}
            digitMode={digitMode}
            onJumpToPlan={() => {
              setActiveTab('plan');
              setWizardStep(4);
            }}
          />
        )}

        {activeTab === 'nasa' && (
          <NasaTransparencyPage
            telemetry={telemetry}
            telemetryLoading={telemetryLoading}
            onRefreshTelemetry={() => void fetchTelemetry(farm.lat, farm.lon, true)}
            plan={plans[activeStrategy]}
            lang={lang}
            digitMode={digitMode}
          />
        )}

        {activeTab === 'crops' && <CropAtlasPage lang={lang} digitMode={digitMode} />}
      </main>

      {/* Honest NASA Attribution Footer */}
      <footer className="border-t border-slate-200 bg-white/80 py-4 px-4 text-center text-xs font-semibold text-slate-500">
        {t.footerAck}
      </footer>

      {/* Mobile Bottom Navigation Bar (compact <= 64px) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 grid grid-cols-4 h-16"
      >
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex flex-col items-center justify-center gap-1 text-[11px] font-bold cursor-pointer ${
                active ? 'text-emerald-700' : 'text-slate-500'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="truncate max-w-[78px]">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
